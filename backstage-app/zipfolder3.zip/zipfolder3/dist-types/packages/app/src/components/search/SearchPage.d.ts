/// <reference types="react" />
export declare const searchPage: JSX.Element;
