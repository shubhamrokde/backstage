/// <reference types="react" />
declare const LogoIcon: () => JSX.Element;
export default LogoIcon;
