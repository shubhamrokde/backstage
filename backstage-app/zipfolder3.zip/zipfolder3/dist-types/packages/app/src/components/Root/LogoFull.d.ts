/// <reference types="react" />
declare const LogoFull: () => JSX.Element;
export default LogoFull;
