/// <reference types="react" />
declare const App: () => JSX.Element;
export default App;
